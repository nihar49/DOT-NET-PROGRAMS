﻿using System;


namespace MovieTicketing
{
    public class Tickets
    {
        //TODO: Write code here.

        public int TicketID { get; set; }
        public int ShowID { get; set; }
        public string CustomerName { get; set; }
        public string ReferenceCode { get; set; }
        public DateTime BookingDate { get; set; }
        public int NumberofPersons { get; set; }
        public decimal Amount { get; set; }
        public string TicketStatus { get; set; }

        public Tickets()
        {

        }

    }
}
