﻿using System;
using System.Data.SqlClient;

namespace MovieTicketing
{
    public class TicketingDataAccess
    {
        string ConnectionString = "Data Source=.;Initial Catalog=MovieTicketing;User ID=sa;Password=wipro@123";

        public bool AddMovie(Movies obj)
        {
            //throw new NotImplementedException();
            Boolean isAdded = false;
            if (obj == null)
                return isAdded;
            else
            {
                SqlConnection con = new SqlConnection(ConnectionString);
               
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into Movies (MOVIENAME,DIRECTOR,PLAYSPERDAY,TICKETPRICE) values (@mn,@dir,@ppd,@tp)";
                cmd.Parameters.AddWithValue("@mn", obj.MovieName);
                cmd.Parameters.AddWithValue("@dir", obj.DirectorName);
                cmd.Parameters.AddWithValue("@ppd", obj.PlaysPerDay);
                cmd.Parameters.AddWithValue("@tp", obj.TicketPrice);

                cmd.Connection = con;
                con.Open();
                int add = cmd.ExecuteNonQuery();
                if (add != 0)
                {
                    isAdded = true;
                }
                else
                    isAdded = false;

                con.Close();
               

            }



            return isAdded;


        }

        public bool AddTheatre(Theatres obj)
        {
            // throw new NotImplementedException();

            Boolean isAdded = false;
            if (obj == null)
                return isAdded;
            else
            {
                SqlConnection con = new SqlConnection(ConnectionString);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into Theatres (THEATRENAME,SEATINGCAPACITY) values (@tn,@sc)";
                cmd.Parameters.AddWithValue("@tn", obj.TheatreName);
                cmd.Parameters.AddWithValue("@sc", obj.SeatingCapacity);
                

                cmd.Connection = con;
                con.Open();
                int add = cmd.ExecuteNonQuery();
                if (add != 0)
                {
                    isAdded = true;
                }
                else
                    isAdded = false;

                con.Close();
                return isAdded;

            }






        }

        public bool AddShow(Shows obj)
        {
            // throw new NotImplementedException();
            Boolean isAdded = false;
            if (obj == null)
                return isAdded;
            else
            {
                SqlConnection con = new SqlConnection(ConnectionString);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into Shows(THEATREID,MOVIEID,STARTDATE) values (@tid,@mid,@sd)";
                cmd.Parameters.AddWithValue("@tid", obj.TheatreID);
                cmd.Parameters.AddWithValue("@sd", obj.StartDate);
                cmd.Connection = con;
                con.Open();
                int add = cmd.ExecuteNonQuery();
                if (add != 0)
                {
                    isAdded = true;
                }
                else
                    isAdded = false;

                con.Close();
                return isAdded;

            }
        }

        public string AddTicket(Tickets obj)
        {
            //throw new NotImplementedException();
            if (obj == null)
                return null;
            else
            {
                string moviename = "";
                decimal ticketprice = 0;
                SqlConnection con = new SqlConnection(ConnectionString);

                SqlCommand cmd = new SqlCommand("select m.MovieName,m.TicketPrice from movies m JOIN shows s ON m.MovieID=s.MovieID JOIN tickets t on  s.ShowID=t.ShowID where t.ShowID=@sid ", con);

                cmd.Parameters.AddWithValue("@sid", obj.ShowID);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    moviename = dr["MovieName"].ToString();
                    ticketprice = decimal.Parse(dr["TicketPrice"].ToString());

                }
                else
                {
                    return null;
                }
                con.Close();
                obj.Amount = obj.NumberofPersons * ticketprice;
                Random rand = new Random();
                int random = rand.Next(1, 100);
                string referencecode = obj.CustomerName[0].ToString() + obj.CustomerName[1].ToString() + obj.NumberofPersons.ToString() + moviename[0].ToString() + moviename[1].ToString() + obj.BookingDate.Day.ToString() +
                    obj.BookingDate.Month.ToString() + random.ToString();
                obj.ReferenceCode = referencecode.ToUpper();

                SqlConnection con1 = new SqlConnection(ConnectionString);
                SqlCommand cmd1 = new SqlCommand("insert into Tickets (SHOWID, REFERENCECODE,CUSTOMERNAME,NUMBEROFPERSONS,BOOKINGDATE,AMOUNT,TICKETSTATUS) values(@sid,@ref,@cn,@nop,@bd,@am,@ts)", con1);
                cmd1.Parameters.AddWithValue("@sid", obj.ShowID);
                cmd1.Parameters.AddWithValue("@ref", obj.ReferenceCode);
                cmd1.Parameters.AddWithValue("@cn", obj.CustomerName);
                cmd1.Parameters.AddWithValue("@nop", obj.NumberofPersons);
                cmd1.Parameters.AddWithValue("@bd", obj.BookingDate);
                cmd1.Parameters.AddWithValue("@am", obj.Amount);
                cmd1.Parameters.AddWithValue("@ts", obj.TicketStatus);

                con1.Open();
                int rowcount = cmd1.ExecuteNonQuery();
                con1.Close();
                if (rowcount == 1)
                {
                    return obj.ReferenceCode;
                }
                else
                    return null;
            }

        }


        public int DeleteMovie(int intMovieID)
        {
            if (intMovieID == 0)
            {
                return 0;
            }
            else
            {
                int RowsDeleted = 0;
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("select showID from shows where MovieID=@mid", con);
                cmd.Parameters.AddWithValue("@mid", intMovieID);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        int showID = int.Parse(dr["ShowID"].ToString());
                        SqlConnection con1 = new SqlConnection(ConnectionString);
                        SqlCommand cmd1 = new SqlCommand("Delete from Tickets where ShowID=@sid",con1);
                        cmd1.Parameters.AddWithValue("@sid", showID);
                        con1.Open();
                        int rows = cmd1.ExecuteNonQuery();
                        RowsDeleted += rows;
                        con1.Close();
                    }
                }
                con.Close();
                if (RowsDeleted > 0)
                {

                    SqlCommand cmd2 = new SqlCommand("Delete from Shows where MovieID=@mid", con);
                    cmd2.Parameters.AddWithValue("@mid", intMovieID);
                    con.Open();
                    int rows1 = cmd2.ExecuteNonQuery();
                    con.Close();
                    RowsDeleted += rows1;
                }
                    if (RowsDeleted > 0)
                    {
                        SqlCommand cmd3 = new SqlCommand("Delete from Movies where MovieID=@mid", con);
                        cmd3.Parameters.AddWithValue("@mid", intMovieID);
                        con.Open();
                        int rows2 = cmd3.ExecuteNonQuery();
                        RowsDeleted += rows2;
                        con.Close();
                    }
                //con.Close();
                if (RowsDeleted >0)
                {
                    return RowsDeleted;
                }
                else
                {
                    return 0;
                }
                

            }

            // throw new NotImplementedException();
        }

        }


    }

