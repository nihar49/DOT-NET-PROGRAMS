﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AssetManagement
{
    public class AssetTracking
    {
        const string ConnectionString = "Data Source=.;Initial Catalog=AssetManagement;User ID=sa;Password=wipro@123";
        public bool AddAsset(Asset obj)
        {
            //throw new NotImplementedException();
            bool isAdded = false;
            if (obj == null)
                return isAdded;
            else
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                string SerialNo = "";
                Random rand = new Random();
                int random = rand.Next(1, 1000);
                SerialNo = obj.AssetType[0].ToString() + obj.AssetType[1].ToString() + random.ToString();
                SqlCommand cmd = new SqlCommand("Insert into Asset (ASSETTYPE,SERIALNO,PROCUREMENTDATE,TAGGINGSTATUS) values(@at,@sn,@pd,@ts)", con);
                cmd.Parameters.AddWithValue("@at", obj.AssetType);
                cmd.Parameters.AddWithValue("@sn", SerialNo);
                cmd.Parameters.AddWithValue("@pd", DateTime.Now);
                cmd.Parameters.AddWithValue("@ts", "Free Pool");
                con.Open();
                int rowcount = cmd.ExecuteNonQuery();
                con.Close();
                if(rowcount>0)
                {
                    isAdded = true; ;
                }
                else
                {
                    isAdded = false;
                }

                return isAdded;

            }




        }

        public bool ModifyAsset(Asset obj)
        {
            // throw new NotImplementedException();
            bool isModified = false;
            if (obj == null)
                return isModified;
            else
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                string SerialNo = "";
                Random rand = new Random();
                int random = rand.Next(1, 1000);
                SerialNo = obj.AssetType[0].ToString() + obj.AssetType[1].ToString() + random.ToString();
                SqlCommand cmd = new SqlCommand("Update Asset set ASSETTYPE=@at,SERIALNO=@sn,PROCUREMENTDATE=@pd,TAGGINGSTATUS=@ts where ASSETID=@aid", con);
                cmd.Parameters.AddWithValue("@aid", obj.AssetID);
                cmd.Parameters.AddWithValue("@at", obj.AssetType);
                cmd.Parameters.AddWithValue("@sn",SerialNo);
                cmd.Parameters.AddWithValue("@pd", obj.ProcurementDate);
                cmd.Parameters.AddWithValue("@ts", obj.TaggingStatus);
                con.Open();
                int rowcount = cmd.ExecuteNonQuery();
                con.Close();
                if(rowcount>0)
                {
                    isModified = true;
                }
                else
                {
                    isModified = false;
                }
            }
            return isModified;
        }

        public bool TagAsset(AssetTagging obj)
        {
            //throw new NotImplementedException();
            bool isTagged = false;
            if (obj == null)
                return isTagged;
            else
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("Select TaggingStatus from Asset where AssetID=@aid",con);
                cmd.Parameters.AddWithValue("@aid", obj.AssetID);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                
                string status = "";
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        status = dr["TAGGINGSTATUS"].ToString();
                        if (status == "Free Pool")
                        {
                            SqlConnection con1 = new SqlConnection(ConnectionString);
                            SqlCommand cmd1 = new SqlCommand("Insert into AssetTagging (EmployeeID,AssetID,TaggingDate,ReleaseDate) values (@eid,@aid,@td,null)", con1);
                            cmd1.Parameters.AddWithValue("@eid", obj.EmployeeID);
                            cmd1.Parameters.AddWithValue("@aid", obj.AssetID);
                            cmd1.Parameters.AddWithValue("@td", obj.TaggingDate);
                            //cmd1.Parameters.AddWithValue("@rd", null);
                            con1.Open();
                            int rows = cmd1.ExecuteNonQuery();
                            con1.Close();
                            if (rows > 0)
                            {
                                SqlConnection con2 = new SqlConnection(ConnectionString);
                                SqlCommand cmd2 = new SqlCommand("Update Asset set TaggingStatus=@ts", con2);
                                cmd2.Parameters.AddWithValue("@ts", "Tagged");
                                con2.Open();
                                cmd2.ExecuteNonQuery();
                                con2.Close();
                                isTagged = true;
                            }

                        }



                    }
                }
                else
                {
                    isTagged = false;
                }
                con.Close();


            }

            return isTagged;
        }

        public bool DeTagAsset(int intAssetId)
        {
            throw new NotImplementedException();
        }
    }
}
