﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MyWebApp1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void CheckBoxList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            Label1.Text = "Name is:" + txtFirstName.Text + " " + txtLastName.Text + "<br/>" +
                "Date of Birth is:" + txtDateOfBirth.Text + "<br/>" + "Gender is:" + RadiobtnListGender.Text +
              "<br/>" + "State is:" + DropListState.Text + "<br/>" + "Languages known are:";

            foreach(ListItem item in ChkBoxLanguages.Items)
            {
                if (item.Selected)
                {
                    Label1.Text = Label1.Text +" "+ item.Value;
                }
            }


        }

        protected void btnImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (ImgCalendar1.Visible)
                ImgCalendar1.Visible = false;
            else
                ImgCalendar1.Visible = true;
        }

        protected void ImgCalendar1_SelectionChanged(object sender, EventArgs e)
        {
            txtDateOfBirth.Text = ImgCalendar1.SelectedDate.ToShortDateString();
            ImgCalendar1.Visible = false;
        }
    }
}