﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace MyWebApp1
{
    public partial class ADO : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Select * From Employee";
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            GridView1.DataSource = dr;
            GridView1.DataBind();
            con.Close();
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "insert into Employee (EmpName,Age,Address,Dpt_id) values(@en,@age,@add,@did)";
            cmd.Parameters.AddWithValue("@en", txtName.Text);
            cmd.Parameters.AddWithValue("@age", txtAge.Text);
            cmd.Parameters.AddWithValue("@add", txtAddress.Text);
            cmd.Parameters.AddWithValue("@did", txtDeptID.Text);

            cmd.Connection = con;
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
           
            con.Close();
            if(rowcount==1)
            {
                Response.Write("Record Inserted");
            }


        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Update Employee set EmpName=@en,Age=@age,Address=@add,Dpt_id=@did where EmpID=@id";
            cmd.Parameters.AddWithValue("@id", txtEmpID.Text);
            cmd.Parameters.AddWithValue("@en", txtName.Text);
            cmd.Parameters.AddWithValue("@age", txtAge.Text);
            cmd.Parameters.AddWithValue("@add", txtAddress.Text);
            cmd.Parameters.AddWithValue("@did", txtDeptID.Text);

            cmd.Connection = con;
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
            con.Close();
            if(rowcount==1)
            {
                Response.Write("Record Updated");
            }



        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText="Delete from Employee where EmpID=@eid";
            cmd.Parameters.AddWithValue("@eid", txtEmpID.Text);

            cmd.Connection = con;
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
            con.Close();
            if(rowcount==1)
            {
                Response.Write("Record Deleted");
            }

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Select * from Employee where EmpID=@eid";
            cmd.Parameters.AddWithValue("@eid", txtEmpID.Text);
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if(dr.HasRows)
            {
                dr.Read();
                txtName.Text = dr["EmpName"].ToString();
                txtAge.Text = dr["Age"].ToString();
                txtAddress.Text = dr["Address"].ToString();
                txtDeptID.Text = dr["Dpt_id"].ToString();

            }
            else
            {
                Response.Write("Record Not Found");
            }

            con.Close();
        }

        protected void txtEmpID_TextChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}