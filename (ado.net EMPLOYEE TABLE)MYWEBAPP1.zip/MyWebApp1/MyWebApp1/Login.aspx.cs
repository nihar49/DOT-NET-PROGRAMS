﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MyWebApp1
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {

            if (txtFirstName.Text == "Nihar" && txtEmail.Text == "Wipro.com")
            {
                Response.Redirect("Home.aspx");
            }
            else
                LabelErrorMessage.Text = "Invalid input";
        }
    }
}