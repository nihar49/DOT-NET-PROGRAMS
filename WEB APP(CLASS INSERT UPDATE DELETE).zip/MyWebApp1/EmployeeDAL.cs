﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
namespace MyWebApp1
{
    public class EmployeeDAL
    {
        public List<Employee> viewAllEmployees()
        {
            List<Employee> empList = new List<Employee>();
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Select * From employee1";
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
           if(dr.HasRows)
            {
                while(dr.Read())
                {
                    Employee emp = new Employee();
                    emp.EmpID = int.Parse(dr["EmpID"].ToString());
                    emp.EmpName = dr["EmpName"].ToString();
                    emp.Age= int.Parse(dr["Age"].ToString());
                    emp.Address= dr["Address"].ToString();
                    emp.Did= int.Parse(dr["Did"].ToString());
                    empList.Add(emp);
                }
            }
            con.Close();
            return empList;

        }

        public int AddEmployee(Employee emp)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "insert into employee1 (EmpName,Age,Address,Did) values(@en,@age,@add,@did);select scope_identity()";
            cmd.Parameters.AddWithValue("@en", emp.EmpName);
            cmd.Parameters.AddWithValue("@age", emp.Age);
            cmd.Parameters.AddWithValue("@add", emp.Address);
            cmd.Parameters.AddWithValue("@did", emp.Did);

            cmd.Connection = con;
            con.Open();
           // if(dr["Did"]!=DBNull.Value)
            int EmpID = int.Parse(cmd.ExecuteScalar().ToString());
            con.Close();
            return EmpID;


        }

        public bool UpdateEmployee(Employee emp)
        {
            bool isUpdated = false;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Update Employee1 set EmpName=@en,Age=@age,Address=@add,Did=@did where EmpID=@id";
            cmd.Parameters.AddWithValue("@id",emp.EmpID );
            cmd.Parameters.AddWithValue("@en", emp.EmpName);
            cmd.Parameters.AddWithValue("@age", emp.Age);
            cmd.Parameters.AddWithValue("@add", emp.Address);
            cmd.Parameters.AddWithValue("@did", emp.Did);

            cmd.Connection = con;
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
            con.Close();
            if (rowcount == 1)
            {
                isUpdated = true;
            }

            return isUpdated;

        }

        public bool DeleteEmployee(int empID)
        {
            Boolean isDeleted = false;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Delete from Employee1 where EmpID=@eid";
            cmd.Parameters.AddWithValue("@eid", empID);

            cmd.Connection = con;
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
            con.Close();
            if (rowcount == 1)
            {
                isDeleted = true;
            }


            return isDeleted;

        }

        public Employee SearchEmployee(int empID)
        {
            Employee emp = new Employee();
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Select * from Employee1 where EmpID=@eid";
            cmd.Parameters.AddWithValue("@eid", empID);
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                emp.EmpName = dr["EmpName"].ToString();
                emp.Age = int.Parse(dr["Age"].ToString());
                emp.Address = dr["Address"].ToString();
                emp.Did = int.Parse(dr["Did"].ToString());

            }
            

            con.Close();
            return emp;




        }



    }
}