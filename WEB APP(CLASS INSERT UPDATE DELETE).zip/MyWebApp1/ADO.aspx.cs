﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace MyWebApp1
{
    public partial class ADO : System.Web.UI.Page
    {
        EmployeeDAL obj = new EmployeeDAL();
        protected void Page_Load(object sender, EventArgs e)
        {
            /*SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Select * From Employee";
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            GridView1.DataSource = dr;
            GridView1.DataBind();
            con.Close();*/

            List<Employee> eList = obj.viewAllEmployees();
            GridView1.DataSource = eList;
            GridView1.DataBind();


        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            /*SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "insert into Employee (EmpName,Age,Address,Dpt_id) values(@en,@age,@add,@did)";
            cmd.Parameters.AddWithValue("@en", txtName.Text);
            cmd.Parameters.AddWithValue("@age", txtAge.Text);
            cmd.Parameters.AddWithValue("@add", txtAddress.Text);
            cmd.Parameters.AddWithValue("@did", txtDeptID.Text);

            cmd.Connection = con;
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
           
            con.Close();
            if(rowcount==1)
            {
                Response.Write("Record Inserted");
            }*/

            Employee e1 = new Employee();
            e1.EmpName = txtName.Text;
            e1.Age = int.Parse(txtAge.Text);
            e1.Address = txtAddress.Text;
            e1.Did = int.Parse(txtDeptID.Text);
            int empid = obj.AddEmployee(e1);
            if(empid!=0)
            {
                Response.Write("Record inserted:Employee ID is:" + empid);
            }
            else
            {
                Response.Write("Record not inserted");
            }

        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            /*SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Update Employee set EmpName=@en,Age=@age,Address=@add,Dpt_id=@did where EmpID=@id";
            cmd.Parameters.AddWithValue("@id", txtEmpID.Text);
            cmd.Parameters.AddWithValue("@en", txtName.Text);
            cmd.Parameters.AddWithValue("@age", txtAge.Text);
            cmd.Parameters.AddWithValue("@add", txtAddress.Text);
            cmd.Parameters.AddWithValue("@did", txtDeptID.Text);

            cmd.Connection = con;
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
            con.Close();
            if(rowcount==1)
            {
                Response.Write("Record Updated");
            }*/

            Employee e1 = new Employee();
            e1.EmpID = int.Parse(txtEmpID.Text);
            e1.EmpName = txtName.Text;
            e1.Age = int.Parse(txtAge.Text);
            e1.Address = txtAddress.Text;
            e1.Did = int.Parse(txtDeptID.Text);

            bool isUpdated = obj.UpdateEmployee(e1);

            if(isUpdated)
            {
                Response.Write("Record Updated!!!");
            }
            else
            {
                Response.Write("Record Not Found");
            }
            

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            /* SqlConnection con = new SqlConnection();
             con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;password=wipro@123";
             SqlCommand cmd = new SqlCommand();
             cmd.CommandText="Delete from Employee where EmpID=@eid";
             cmd.Parameters.AddWithValue("@eid", txtEmpID.Text);

             cmd.Connection = con;
             con.Open();
             int rowcount = cmd.ExecuteNonQuery();
             con.Close();
             if(rowcount==1)
             {
                 Response.Write("Record Deleted");
             }*/

            bool isDeleted = obj.DeleteEmployee(int.Parse(txtEmpID.Text));
            
            if(isDeleted)
            {
                Response.Write("Record Deleted");
            }
            else
            {
                Response.Write("Record Not deleted");
            }

            

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            /* SqlConnection con = new SqlConnection();
             con.ConnectionString = "Server=.;Initial Catalog=DemoDB;User Id=sa;password=wipro@123";
             SqlCommand cmd = new SqlCommand();
             cmd.CommandText = "Select * from Employee where EmpID=@eid";
             cmd.Parameters.AddWithValue("@eid", txtEmpID.Text);
             cmd.Connection = con;
             con.Open();
             SqlDataReader dr = cmd.ExecuteReader();
             if(dr.HasRows)
             {
                 dr.Read();
                 txtName.Text = dr["EmpName"].ToString();
                 txtAge.Text = dr["Age"].ToString();
                 txtAddress.Text = dr["Address"].ToString();
                 txtDeptID.Text = dr["Dpt_id"].ToString();

             }
             else
             {
                 Response.Write("Record Not Found");
             }

             con.Close();*/

            Employee emp = obj.SearchEmployee(int.Parse(txtEmpID.Text));
            if(emp!=null)
            {
                txtName.Text = emp.EmpName;
                txtAge.Text = emp.Age.ToString();
                txtAddress.Text = emp.Address;
                txtDeptID.Text = emp.Did.ToString();
            }
            else
            {
                Response.Write("Record Not Found:");
            }


        }

        protected void txtEmpID_TextChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}