﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoterEntry.Utility
{
    public class VoterUtility
    {
        public string GenerateVoterID(string strFirstName, string strLastName, DateTime dtDateofBirth)
        {
            char a = strFirstName[0];
            char b = strLastName[0];
            string month = dtDateofBirth.DayOfWeek.ToString();
            char m = month[0];
            string strVoterID = a.ToString() + b.ToString() + m.ToString() + strFirstName.Length.ToString() + strLastName.Length.ToString() +
                SumDigits(dtDateofBirth.Month) + SumDigits(dtDateofBirth.Day) + SumDigits(dtDateofBirth.Year);

            return strVoterID;


        }

        public string SumDigits(int value)
        {

            int sum = 0;

            while (value != 0)
            {
                sum = sum + value % 10;
                value = value / 10;
            }

            return sum.ToString();

        }
    }
}
