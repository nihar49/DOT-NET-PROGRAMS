﻿using System;
using System.Collections.Generic;
namespace VoterEntry
{
    public class VoterManagement
    {
       // TODO: Write your code here
       List<Voter> VoterList { get; set; }

        public VoterManagement()
        {
            VoterList = new List<Voter>();
        }

        public string AddVoter(Voter obj)
        {
          
            string VoteriD = null;
            if (obj == null)
            {
                return VoteriD;
            }
            else
            {
                if (string.IsNullOrEmpty(obj.FirstName) || string.IsNullOrEmpty(obj.LastName) || string.IsNullOrEmpty(obj.DateofBirth.ToString())
                    || string.IsNullOrEmpty(obj.Address) || string.IsNullOrEmpty(obj.ConstituencyName) || string.IsNullOrEmpty(obj.FathersName) ||
                    string.IsNullOrEmpty(obj.Gender))
                {
                    return null; ;
                }
                else
                {
                    try
                    {
                        Utility.VoterUtility ObjUtility = new Utility.VoterUtility();
                    obj.VoterID = ObjUtility.GenerateVoterID(obj.FirstName, obj.LastName, obj.DateofBirth);
                    obj.age = DateTime.Now.Subtract(obj.DateofBirth).Days / 365;

                   
                        if (obj.age >= 18)
                        {
                            VoterList.Add(obj);
                            VoteriD = obj.VoterID;
                        }
                        else {
                            throw new VoterEntry.Exceptions.AgeException("Age shouldn't be less than 18");
                        }


                        /*if (obj.age < 18)
                        {
                            throw new VoterEntry.Exceptions.AgeException("Age is less than 18");
                        }*/
                    }
                    catch(VoterEntry.Exceptions.AgeException o)
                    {
                        Console.WriteLine(o.Message);
                        throw o;
                       
                        /* {
                             VoterList.Add(obj);
                             VoteriD = obj.VoterID;
                         } */


                    }

                }
            }

            return VoteriD;

        }

        public bool ModifyVoter(Voter obj)
        {
            Boolean isModified = false;

            
            if (obj == null)
            {
                isModified = false;
            }
            else
            {
                if (string.IsNullOrEmpty(obj.FirstName) || string.IsNullOrEmpty(obj.LastName) || string.IsNullOrEmpty(obj.DateofBirth.ToString())
                    || string.IsNullOrEmpty(obj.Address) || string.IsNullOrEmpty(obj.ConstituencyName) || string.IsNullOrEmpty(obj.FathersName) ||
                    string.IsNullOrEmpty(obj.Gender))
                {
                    return isModified;
                }
                else
                {
                    try
                    {
                        Utility.VoterUtility ObjUtility = new Utility.VoterUtility();
                        obj.VoterID = ObjUtility.GenerateVoterID(obj.FirstName, obj.LastName, obj.DateofBirth);
                        obj.age = DateTime.Now.Subtract(obj.DateofBirth).Days / 365;


                        if (obj.age >= 18)
                        {
                            for (int i = 0; i < VoterList.Count; i++)
                            {
                                if (VoterList[i].VoterID == obj.VoterID)
                                {
                                    VoterList[i] = obj;
                                    isModified = true;
                                }
                            }
                        }
                        else
                        {
                            throw new VoterEntry.Exceptions.AgeException("Age shouldn't be less than 18");
                        }



                        /*if (obj.age < 18)
                        {
                            throw new VoterEntry.Exceptions.AgeException("Age is less than 18");
                        }*/
                    }
                    catch (VoterEntry.Exceptions.AgeException o)
                    {
                        Console.WriteLine(o.Message);
                        throw o;

                        /* {
                             VoterList.Add(obj);
                             VoteriD = obj.VoterID;
                         } */


                    }

                }
            }
            return isModified;


        }






        

        public Voter SearchVoter(string strVoterID)
        {
            Voter e = null;

            if (strVoterID == null)
                return e;
            else
            {
                for (int i = 0; i < VoterList.Count; i++)
                {
                    if (VoterList[i].VoterID == strVoterID)
                    {
                        e = VoterList[i];
                    }
                }
            }

            return e;


        }

        public bool DeleteVoter(string strVoterID)
        {
            bool isDeleted = false;

            if (strVoterID == null)
                isDeleted = false;
            else
            {
                for (int i = 0; i < VoterList.Count; i++)
                {
                    if (VoterList[i].VoterID == strVoterID)
                    {
                        VoterList.RemoveAt(i);
                        isDeleted = true;
                    }
                }

                
            }
            return isDeleted;

        }

        public List<Voter> GetVoterList()
        {
            return VoterList;
        }
    }
}
