﻿using System;

namespace VoterEntry
{
    public class Voter
    {
        // TODO: Write your code Here


        public string VoterID { get; set; }
        public string FirstName { get; set; }

        public string LastName { get; set; }
        public DateTime DateofBirth { get; set; }
        public int age { get; set; }
        public string FathersName { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public string ConstituencyName { get; set; }

        public Voter(){}

        public Voter(string VoterID,string FirstName,string LastName,DateTime DateofBirth, int age,string FathersName, 
            string Gender, string Address,string ConstituencyName)
        {
            this.VoterID = VoterID;
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.DateofBirth = DateofBirth;
            this.age = age;
            this.FathersName = FathersName;
            this.Gender = Gender;
            this.Address = Address;
            this.ConstituencyName = ConstituencyName;
        }


    }
}
