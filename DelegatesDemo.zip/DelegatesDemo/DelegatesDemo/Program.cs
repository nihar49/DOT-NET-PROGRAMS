﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo
{
    class Program
    {
        // Declare the delegate.
        public delegate void MathDelegate(int a, int b);
        static public void Add(int a, int b)
        {
            Console.WriteLine("Sum :"+(a+b));
        }

        static public void Subtract(int a, int b)
        {
            Console.WriteLine("Difference :"+(a-b));
        }
        static void Main(string[] args)
        {
            // Creating the Delegate instance.
            MathDelegate obj = new MathDelegate(Add);

            // Invoking the delegate.
            obj(10, 20);

            // Adding more methods.

            obj += Subtract;
            Console.WriteLine("After adding subtract");
            obj(10, 2);
            Console.WriteLine("After removing add");
            obj -= Add;

            obj(10, 2);

            obj += delegate (int a, int b) { Console.WriteLine("Multiplication:"+(a*b)); }; // Anonymous method

            obj(100, 200);
        }
    }
}
