﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManagement
{
    public class ProjectUtility
    {
        public string GenerateProjectID(string strProjectName)
        {
            string id = "";
            int count = 0;
            string[] s = strProjectName.Split(' ');
            foreach(string k in s)
            {
                count++;
            }

            if(count==1)
            {
                id = s[0].Substring(0, 3);
                id = id.ToUpper();
            }
            if(count==2)
            {
                id = s[0].Substring(0, 1) + s[1].Substring(0,2);
                id = id.ToUpper();

            }
            if(count==3)
            {
                id = s[0].Substring(0, 1) + s[1].Substring(0, 1) + s[2].Substring(0, 1);
                id = id.ToUpper();
            }

            return id;
            //throw new NotImplementedException();
        }
    }
}
